# bcsfe-ja

Battle Cats Save File Editor (Japanese Localization)

## Installation

```bash
pip install bcsfe-ja
```

## Usage

```bash
bcsfe-ja
```
